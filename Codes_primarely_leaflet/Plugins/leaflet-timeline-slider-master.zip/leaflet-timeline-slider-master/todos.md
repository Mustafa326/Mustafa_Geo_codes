# TODOs...
- Fix example timing of marker adding error on Lexington/Concord map
- Fix weird mozilla squigly on input line
- Make sure onRemove is working correctly
- Make another example with more customizable options set