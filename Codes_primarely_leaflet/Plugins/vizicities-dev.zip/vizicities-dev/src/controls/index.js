import Orbit, {orbit} from './Controls.Orbit';

const Controls = {
  Orbit: Orbit,
  orbit, orbit
};

export default Controls;
