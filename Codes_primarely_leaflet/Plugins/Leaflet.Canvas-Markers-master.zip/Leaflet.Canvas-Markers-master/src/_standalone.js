var factory = require("./plugin/leaflet.canvas-markers");

window.L.CanvasIconLayer = factory(L);
